define({
  "showLegend": "Tampilkan legenda",
  "controlPopupMenuTitle": "Pilih tindakan mana yang akan ditampilkan pada menu konteks layer.",
  "zoomto": "Perbesar hingga",
  "transparency": "Transparansi",
  "controlPopup": "Aktifkan / Nonaktifkan Pop-up",
  "moveUpAndDown": "Pindahkan ke atas/ke bawah",
  "attributeTable": "Buka Tabel Atribut",
  "url": "Deskripsi / Tampilkan Detail Item / Unduhan",
  "layerSelectorTitle": "Pilih layer mana yang akan ditampilkan pada daftar."
});
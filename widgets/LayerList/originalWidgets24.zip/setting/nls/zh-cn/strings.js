define({
  "showLegend": "显示图例",
  "controlPopupMenuTitle": "选择将在图层上下文菜单中显示的操作。",
  "zoomto": "缩放至",
  "transparency": "透明度",
  "controlPopup": "启用/禁用弹出窗口",
  "moveUpAndDown": "上移/下移",
  "attributeTable": "打开属性表",
  "url": "描述/显示项目详细信息/下载",
  "layerSelectorTitle": "选择将在列表中显示的图层。"
});
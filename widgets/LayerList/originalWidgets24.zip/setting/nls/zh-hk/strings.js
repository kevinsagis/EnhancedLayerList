define({
  "showLegend": "顯示圖例",
  "controlPopupMenuTitle": "選擇要在圖層上下文功能表中顯示的動作。",
  "zoomto": "縮放至",
  "transparency": "透明度",
  "controlPopup": "啟用/停用快顯視窗",
  "moveUpAndDown": "上移/下移",
  "attributeTable": "開啟屬性工作表",
  "url": "描述/顯示項目詳細資訊/下載",
  "layerSelectorTitle": "選擇要在清單中顯示的圖層。"
});
define({
  "showLegend": "Prikaži legendu",
  "controlPopupMenuTitle": "Odaberite koje će se radnje prikazivati u izborniku konteksta sloja.",
  "zoomto": "Povećaj na",
  "transparency": "Prozirnost",
  "controlPopup": "Omogući / onemogući skočni prozor",
  "moveUpAndDown": "Premjesti gore / Premjesti dolje",
  "attributeTable": "Otvori atributnu tablicu",
  "url": "Opis / Prikaži pojedinosti o stavci / Preuzimanje",
  "layerSelectorTitle": "Izaberite koji će se slojevi prikazati na popisu."
});
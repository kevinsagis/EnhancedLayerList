define({
  "showLegend": "הצג מקרא",
  "controlPopupMenuTitle": "בחר אילו פעולות יוצגו בתפריט השכבה.",
  "zoomto": "התמקד אל",
  "transparency": "שקיפות",
  "controlPopup": "הפעל / השבת חלון קופץ",
  "moveUpAndDown": "הזז למעלה / הזז למטה",
  "attributeTable": "פתח טבלת מאפיינים",
  "url": "תיאור / הצגת פרטי פריט / הורדה",
  "layerSelectorTitle": "בחר אילו שכבות יוצגו ברשימה."
});
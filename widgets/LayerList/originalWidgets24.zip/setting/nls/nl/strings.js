define({
  "showLegend": "Legenda weergeven",
  "controlPopupMenuTitle": "Kies welke acties worden weergegeven in het laagcontextmenu.",
  "zoomto": "Zoomen naar",
  "transparency": "Transparant",
  "controlPopup": "Pop-up inschakelen / uitschakelen",
  "moveUpAndDown": "Omhoog / omlaag",
  "attributeTable": "Attributentabel openen",
  "url": "Beschrijving / Itemdetails weergeven / Downloaden",
  "layerSelectorTitle": "Kies welke lagen worden aangegeven op de lijst."
});
define({
  "showLegend": "Pokaż legendę",
  "controlPopupMenuTitle": "Wybierz działania, które będą wyświetlane w menu kontekstowym warstwy.",
  "zoomto": "Powiększ do",
  "transparency": "Przezroczystość",
  "controlPopup": "Włącz / Wyłącz okno podręczne",
  "moveUpAndDown": "Przenieś do góry / Przenieś w dół",
  "attributeTable": "Otwórz tabelę atrybutów",
  "url": "Opis / Pokaż szczegóły elementu / Pobierz",
  "layerSelectorTitle": "Wybierz warstwy, które zostaną wymienione na liście."
});
define({
  "showLegend": "Näytä selite",
  "controlPopupMenuTitle": "Valitse, mitkä toiminnot näytetään karttatason kontekstivalikossa.",
  "zoomto": "Tarkenna kohteeseen",
  "transparency": "Transparency",
  "controlPopup": "Poista popup-ikkuna käytöstä tai ota se käyttöön",
  "moveUpAndDown": "Siirrä ylös / Siirrä alas",
  "attributeTable": "Avaa ominaisuustietotaulu",
  "url": "Kuvaus / Näytä kohteen tiedot / Lataa",
  "layerSelectorTitle": "Valitse, mitkä karttatasot näytetään luettelossa."
});
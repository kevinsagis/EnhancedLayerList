define({
  "showLegend": "Rādīt leģendu",
  "controlPopupMenuTitle": "Izvēlieties, kuras darbības tiks rādītas slāņa konteksta izvēlnē.",
  "zoomto": "Pietuvināt",
  "transparency": "Caurspīdīgums",
  "controlPopup": "Iespējot/atspējot uznirstošo logu",
  "moveUpAndDown": "Pārvietot uz augšu/uz leju",
  "attributeTable": "Atvērt atribūtu tabulu",
  "url": "Apraksts/Rādīt detalizētu vienuma informāciju/Lejupielādēt",
  "layerSelectorTitle": "Izvēlieties, kuri slāņi tiks rādīti sarakstā."
});
define({
  "showLegend": "범례 보기",
  "controlPopupMenuTitle": "레이어 상황 메뉴에 표시할 작업을 선택합니다.",
  "zoomto": "확대/축소",
  "transparency": "투명도",
  "controlPopup": "팝업 활성화/비활성화",
  "moveUpAndDown": "위로/아래로 이동",
  "attributeTable": "속성 테이블 열기",
  "url": "설명/항목 세부정보 보기/다운로드",
  "layerSelectorTitle": "목록에 표시할 레이어를 선택합니다."
});
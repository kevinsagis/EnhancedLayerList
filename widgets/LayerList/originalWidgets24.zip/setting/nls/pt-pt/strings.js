define({
  "showLegend": "Mostrar legenda",
  "controlPopupMenuTitle": "Selecione as ações que serão exibidas no menu de contexto da camada.",
  "zoomto": "Efectuar zoom para",
  "transparency": "Transparência",
  "controlPopup": "Activar / Desactivar Pop-up",
  "moveUpAndDown": "Mover para cima / Mover para baixo",
  "attributeTable": "Abrir tabela de atributos",
  "url": "Descrição / Mostrar Detalhes de Item / Descarregar",
  "layerSelectorTitle": "Selecione que camadas serão exibidas na lista."
});
define({
  "showLegend": "Legende anzeigen",
  "controlPopupMenuTitle": "Legen Sie fest, welche Aktionen im Kontextmenü für Layer angezeigt werden sollen.",
  "zoomto": "Zoomen auf",
  "transparency": "Transparenz",
  "controlPopup": "Pop-up aktivieren/deaktivieren",
  "moveUpAndDown": "Nach oben/Nach oben",
  "attributeTable": "Attributtabelle öffnen",
  "url": "Beschreibung/Elementdetails anzeigen/Herunterladen",
  "layerSelectorTitle": "Legen Sie fest, welche Layer in der Liste angezeigt werden sollen."
});
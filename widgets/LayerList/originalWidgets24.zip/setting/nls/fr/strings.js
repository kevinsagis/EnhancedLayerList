define({
  "showLegend": "Afficher la légende",
  "controlPopupMenuTitle": "Choisissez les actions à afficher dans le menu contextuel de la couche.",
  "zoomto": "Zoom",
  "transparency": "Transparence",
  "controlPopup": "Activer/Désactiver la fenêtre contextuelle",
  "moveUpAndDown": "Remonter/Descendre",
  "attributeTable": "Ouvrir la table attributaire",
  "url": "Description/Afficher les détails des éléments/Télécharger",
  "layerSelectorTitle": "Choisissez les couches à afficher dans la liste."
});
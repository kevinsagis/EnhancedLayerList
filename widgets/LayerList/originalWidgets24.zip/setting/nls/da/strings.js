define({
  "showLegend": "Vis signaturforklaring",
  "controlPopupMenuTitle": "Vælg, hvilke handlinger der skal vises i lagets kontekstmenu.",
  "zoomto": "Zoom til",
  "transparency": "Gennemsigtighed",
  "controlPopup": "Aktivér / Deaktivér pop-up",
  "moveUpAndDown": "Flyt op / Flyt ned",
  "attributeTable": "Åbn attributtabel",
  "url": "Beskrivelse / Vis elementoplysninger / Hent",
  "layerSelectorTitle": "Vælg, hvilke lag der skal vises på listen."
});
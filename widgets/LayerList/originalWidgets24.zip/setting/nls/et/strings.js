define({
  "showLegend": "Kuva legend",
  "controlPopupMenuTitle": "Valige kihi kontekstimenüüs kuvatavad toimingud.",
  "zoomto": "Suumi",
  "transparency": "Läbipaistvus",
  "controlPopup": "Luba / Keela hüpikaknad",
  "moveUpAndDown": "Liigu üles / Liigu alla",
  "attributeTable": "Ava atribuuditabel",
  "url": "Kirjeldus / Kuva sisuüksuse detailid / Allalaadimine",
  "layerSelectorTitle": "Valige loendis kuvatavad kihid."
});